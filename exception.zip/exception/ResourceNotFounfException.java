package com.dh.ClinicaOdontologica.exception;

public class ResourceNotFounfException extends Exception{
    public ResourceNotFounfException(String message){
        super(message);
    }
}
